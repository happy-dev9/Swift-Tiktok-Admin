//
//  discoverCollectionCell.swift
//  TIK TIK
//
//  Created by Rao Mudassar on 08/05/2019.
//  Copyright © 2019 Rao Mudassar. All rights reserved.
//

import UIKit
import SDWebImage

class discoverCollectionCell: UICollectionViewCell {
    
    
    @IBOutlet weak var tik_img: SDAnimatedImageView!
    
}
