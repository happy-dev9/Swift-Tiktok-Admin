//
//  Discover.swift
//  TIK TIK
//
//  Created by Rao Mudassar on 08/05/2019.
//  Copyright © 2019 Rao Mudassar. All rights reserved.
//

import UIKit

    struct ItemVideo {
        
        var video:String! = ""
        var thum:String! = ""
        var liked:String! = "0"
        var like_count:String! = "0"
        var video_comment_count:String! = "0"
        var first_name:String! = ""
        var last_name:String! = ""
        var profile_pic:String! = ""
        var sound_name:String! = ""
        var v_id:String! = "0"
        var u_id:String! = "0"
        
    }
    class Discover: NSObject {
        
        
        var name:String! = ""
        
        var listOfProducts = [ItemVideo]()
        
        
}

